// export const Config = {
//     api : "http://localhost:5000/api"
// }

export const Config = {
    api : "https://myntra-clone-l3or.onrender.com/api"
}