var loginData = [
    {
        //karina
      number: '7083620943',
      otp: '1234',
    },
    // {
    //     //bipin
    //   number: '7871235082',
    //   otp: '123',
    // },
    // {
    //     //yash
    //     number: '6395 320 028',
    //     otp: '123',
    // },
    // {
    //     //rakesh
    //     number: '78946 82213',
    //     otp: '123',
    // },
    // {
    //     //shakti
    //     number: '77424 14814',
    //     otp: '123',
    // },
    // {
    //     //shakti
    //     number: '77424 14814',
    //     otp: '123',
    // },
    // {
    //     //kiran
    //     number: '80896 63158',
    //     otp: '123',
   // }
  ];
  localStorage.setItem('loginData', JSON.stringify(loginData));