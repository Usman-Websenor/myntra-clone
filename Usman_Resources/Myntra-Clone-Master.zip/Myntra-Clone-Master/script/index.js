// var data=JSON.parse(localStorage.getItem("homedata"));
// console.log(data.slideshow);

// slideshow
// var Slideshow=data.slideshow;
// var div=document.querySelector("#slideshow");
// var i=0;
// var image=document.createElement("img");
//   image.src=Slideshow[i];
//   div.append(image);
//   i++;
// setInterval(function(){
//     div.innerHTML=null;
//    image=document.createElement("img");
//   image.src=Slideshow[i];
//   div.append(image);
//   image.addEventListener("click",showpage);
// function showpage(){
//     window.location.href="https://www.myntra.com/myntra-luxe";
// }
//   i++;
//   if(Slideshow.length===i){
//       i=0; 
//   }
// },2000);


